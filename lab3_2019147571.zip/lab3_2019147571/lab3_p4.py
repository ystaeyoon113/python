#import random function
import random
#number defining
N1 = random.randint(1,45)
N2 = random.randint(1,45)
N3 = random.randint(1,45)
N4 = random.randint(1,45)
N5 = random.randint(1,45)
N6 = random.randint(1,45)

#print Lotto(with new line)
print('Lotto numbers of the week:',N1,N2,N3,N4,N5,N6,end='\n')

















