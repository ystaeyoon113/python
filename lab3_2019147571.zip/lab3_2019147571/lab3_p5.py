#user1 input
P1M = int(input('Person 1: Enter month born (1-12): '))
P1D = int(input('Person 1: Enter day born (1-31): '))
P1Y = int(input('Person 1: Enter year born (4-digit): '))
#user2 input
P2M = int(input('Person 2: Enter month born (1-12): '))
P2D = int(input('Person 2: Enter day born (1-31): '))
P2Y = int(input('Person 2: Enter year born (4-digit): '))
#Average Second of Year, Month, Day
SY = (60*60*24*365*4 + 60*60*24)//4
SM = SY//12
SD = 60*60*24
#calculation and print
S = (P1M-P2M)*SM + (P1D-P2D)*SD + (P1Y-P2Y)*SY
print('Age difference in seconds:',format(abs(S),'.0f'))


