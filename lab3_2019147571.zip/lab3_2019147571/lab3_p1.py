#user input
N = int(input('Enter USB size (GB): '))

#defining str, calculation
GIF_Num = int((N*1000000000//(800*600*1/5))) #8Bit = 1Byte, Compression= 5:1
JPEG_Num = int((N*1000000000//(800*600*3/25))) #24Bit = 3Byte, Compression= 25:1
PNG_Num = int((N*1000000000//(800*600*3/8))) #24Bit = 3Byte, Compression= 8:1
TIFF_Num = int(((N*1000000000//(800*600*6/1)))) #48Bit = 6Byte, Compression= 1:1

#print(with xxxxx right-justified)
print(format(GIF_Num,'>5'), 'images in GIF format can be stored')
print(format(JPEG_Num, '>5'), 'images in JPEG format can be stored')
print(format(PNG_Num, '>5'), 'images in PNG format can be stored')
print(format(TIFF_Num, '>5'), 'images in TIFF format can be stored')






