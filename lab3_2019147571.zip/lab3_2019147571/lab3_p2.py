#user input
M = int(input('Enter the first 12 digits of an EAN: '))

#str define
digit_12 = (M//10**0)%10
digit_11 = (M//10**1)%10
digit_10 = (M//10**2)%10
digit_9 = (M//10**3)%10
digit_8 = (M//10**4)%10
digit_7 = (M//10**5)%10
digit_6 = (M//10**6)%10
digit_5 = (M//10**7)%10
digit_4 = (M//10**8)%10
digit_3 = (M//10**9)%10
digit_2 = (M//10**10)%10
digit_1 = (M//10**11)%10

#calculation
A = digit_12+digit_10+digit_8+digit_6+digit_4+digit_2
B = digit_11+digit_9+digit_7+digit_5+digit_3+digit_1
C = 3*A + B
N = 9-(C-1)%10

#print
print('Check digit:',N)
