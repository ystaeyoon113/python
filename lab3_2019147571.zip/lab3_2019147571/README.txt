Lab 3 answers by Kim Taeyoon, student ID 2019147571

Q1: 99