print('# Fahrenheit to Celcius conversion program\n')
print("fahren = float(input('Enter degrees Fahrenheit: '))") #using print("") because print('') causes error
print('celsius = (fahren - 32) * 5 / 9')
print("print(fahren, 'degrees Fahrenheit equals',")   #using print("") because print('') causes error
print(format("format(celsius, '.1f'), 'degrees Celsius')",'>48'))  #format('str','>k') to make blank





