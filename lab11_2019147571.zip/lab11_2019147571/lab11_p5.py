# Pollution/Cancer Correlation Program

import math
from operator import itemgetter

def openFiles():
    '''
        Prompts the user for the file names to open, opens the files,
        and returns the file objects for each in a tuple of the form
        (pollution_datafile, cancer_datafile).

        Raises an OSError exception if the files are not successfully
        opened after four attempts of entering file names.
    '''

    # init
    pollution_datafile_opened = False
    cancer_datafile_opened = False
    num_attempts = 4

    # prompt for file names and attempt to open files
    while ((not pollution_datafile_opened) or \
           (not cancer_datafile_opened)) \
            and (num_attempts > 0):
        try:
            if not cancer_datafile_opened:
                file_name = input('Enter lung cancer data from filename: ')
                cancer_datafile = open(file_name, 'r')
                cancer_datafile_opened = True

            if not pollution_datafile_opened:
                file_name = input('Enter air pollution data from filename: ')
                pollution_datafile = open(file_name, 'r')
                pollution_datafile_opened = True



        except OSError:
            print('File not found:', file_name + '.', 'Please reenter\n')
            num_attempts = num_attempts - 1

    # if one or more files not opened, raise OSError exception
    if not pollution_datafile_opened or not cancer_datafile_opened:
        raise OSError('Too many attempts of reading input files')

    # return file objects if successfully opened
    else:
        return (pollution_datafile, cancer_datafile)


def readFiles(pollution_datafile, cancer_datafile):
    '''
        Reads the data from the provided file objects pollution_datafile
        and cancer_datafile. Returns a list of the data read from each
        in a tuple of the form (pollution_datafile, cancer_datafile).
    '''

    # init
    pollution_data = []
    cancer_data = []
    empty_str = ''

    # read past file headers
    pollution_datafile.readline()
    cancer_datafile.readline()

    # read data files
    eof = False

    while not eof:

        # read line of data from each file
        # and lower it to compare later
        p_line = pollution_datafile.readline()
        p_line = p_line.lower()

        # check if at end-of-file of both files
        if p_line == empty_str:
            eof = True

        # append line of data to each list
        else:
            pollution_data.append(p_line.strip().split(','))

    eof = False

    while not eof:

        # read line of data from each file
        # and lower it to compare later
        c_line = cancer_datafile.readline()
        c_line = c_line.lower()

        # check if at end-of-file of both files
        if c_line == empty_str:
            eof = True

        # append line of data to each list
        else:
            cancer_data.append(c_line.strip().split(','))

    #to compare which word is valid

    #initial setting
    pollution_temp = []
    cancer_temp = []
    pollution_result = []
    cancer_result = []

    #get words in pollution_data
    for i in range(len(pollution_data)):
        pollution_temp.append(pollution_data[i][0])

    #get words which exists in both data
    for i in range(len(cancer_data)):
        if cancer_data[i][0] in pollution_temp:
            cancer_temp.append(cancer_data[i][0])

    #get final list
    for i in range(len(pollution_data)):
        if pollution_data[i][0] in cancer_temp:
            pollution_result.append(pollution_data[i])

    for i in range(len(cancer_data)):
        if cancer_data[i][0] in cancer_temp:
            cancer_result.append(cancer_data[i])

    #sort to match items
    pollution_result.sort(key = itemgetter(0))
    cancer_result.sort(key = itemgetter(0))

    # return list of data from each file
    return (pollution_result, cancer_result)


def calculateCorrelation(pollution_result, cancer_result):
    '''
        Calculates and returns the correlation value for the data
        provided in lists pollution_result and cancer_result
    '''

    # init
    sum_pollution_vals = sum_cancer_vals = 0
    sum_pollution_sqrd = sum_cancer_sqrd = 0
    sum_products = 0

    # calculate intermediate correlation values
    num_values = len(pollution_result)

    for k in range(0, num_values):
        sum_pollution_vals = sum_pollution_vals + float(pollution_result[k][1])
        sum_cancer_vals = sum_cancer_vals + float(cancer_result[k][1])

        sum_pollution_sqrd = sum_pollution_sqrd + \
                           float(pollution_result[k][1]) ** 2
        sum_cancer_sqrd = sum_cancer_sqrd + \
                          float(cancer_result[k][1]) ** 2

        sum_products = sum_products + float(pollution_result[k][1]) * \
                       float(cancer_result[k][1])

    # calculate and display correlation value
    numer = (num_values * sum_products) - \
            (sum_pollution_vals * sum_cancer_vals)

    denom = math.sqrt(abs( \
        ((num_values * sum_pollution_sqrd) - (sum_pollution_vals ** 2)) * \
        ((num_values * sum_cancer_sqrd) - (sum_cancer_vals ** 2)) \
        ))

    return numer / denom


# ---- main

# program greeting
print('This program will determine the correlation (-1 to 1) between')
print('data on air pollution and incidences of lung cancer\n')

try:
    # open data files
    pollution_datafile, cancer_datafile = openFiles()

    # read data
    pollution_result, cancer_result = readFiles(pollution_datafile, cancer_datafile)

    # close data files
    pollution_datafile.close()
    cancer_datafile.close()

    # calculate correlation value
    correlation = calculateCorrelation(pollution_result, cancer_result)

    # display correlation value
    print('r_value = ', correlation)
    print(pollution_result)
    print(cancer_result)

except OSError as e:
    print(e)
    print('Program terminated ...')
