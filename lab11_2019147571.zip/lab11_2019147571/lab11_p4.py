from operator import itemgetter

def getFile():
    '''
        Returns the file name and associated file object for reading the
        file  as tuple of the form (file_name, input_file).
    '''
    input_file_opened = False
    while not input_file_opened:
        try:
            file_name = input('Enter input file name (with extension): ')
            input_file = open(file_name, 'r')
            input_file_opened = True
        except OSError:
            print ('Unable to open input file, please reenter')
    return (file_name, input_file)

def wordCount(line):
    """
    return list that contains words in line
    """
    line = line.lower()

    #word delimiters
    word_delimiters = []
    for string in str(line):
        if string.isalpha() == False:
            word_delimiters.append(string)

    #change word delimiters into ' '
    for n in range(len(word_delimiters)):
        line = line.replace(str(word_delimiters[n]),' ')

    #split into word
    word_temp = line.split(' ')
    word_temp_final = []

    #append new word if string is not blank
    for n in range(len(word_temp)):
        if word_temp[n] != '':
            word_temp_final.append(word_temp[n])

    return word_temp_final

#initial setting
word_list_temp = []
word_list = []
word_dic = {}

# ------------main

#get files
(file_name, input_file) = getFile()

#save word in word_list_temp, and sort it
for line in input_file:
    word_list_temp.extend(wordCount(line))
    word_list_temp.sort()

#if word is in dictionary, value+=1, if empty, append it
for member in word_list_temp:
    try:
        word_dic[member] = word_dic[member] + 1
    except KeyError:
        word_dic[member] = 1

#opening output file
output_file = open(str(file_name)[:-3]+'wc', 'w')

#writing down words
for key in word_dic:
    output_file.write(str(key)+' '+str(word_dic[key])+'\n')

#close files
input_file.close()
output_file.close()