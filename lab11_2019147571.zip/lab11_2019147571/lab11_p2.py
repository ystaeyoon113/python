# Cellular Automation Program

import time
import copy

#user input (size of the 2D cellular automaton)
try:
    SIZE = int(str(input('Grid sidelength (default 20): ')))
    if SIZE < 20:
        SIZE = 20
except:
    SIZE = 20

#user input (maximum generation)
#set Boolian flag to iterate while validInput
invalidInput = True

while invalidInput == True:
    try:
        TIMES = int(str(input('Max generation: ')))
        if TIMES > 0:
            invalidInput = False
        else:
            invalidInput = True
    except:
        invalidInput = True

def printSep():
    '''Print a separator'''
    for ctr in range(0, SIZE+2):
        print('-', end='')
    print('')

def printWorld(world):
    '''Print one generation.
       Must use printSep() above to print the separators.
    '''
    world_copy = copy.deepcopy(world)

    #print
    printSep()

    #print all work through iterate
    y = 0
    while y<SIZE:
        result = ''
        for x in range(len(world_copy[y])):
            result = result + world_copy[y][x]
        result = result.replace('0',' ')
        result = result.replace('1','x')
        print(result,'row',y)
        y = y+1

    printSep()


def liveChange():
    """
    Any live cell with fewer than two live neighbours dies, as if caused by under-population.
    Any live cell with two or three live neighbours lives on to the next generation.
    Any live cell with more than three live neighbours dies, as if by overcrowding.
    Returns list work

    """
    #for cells at 4 corner
    if work[0][1] == '1':
        temp[0][1] = -1
        for y in [0,1]:
            for x in [1,2]:
                if work[y][x] == '1':
                    temp[0][1] = temp[0][1] + 1
    if work[0][1] == '0':
        temp[0][1] = 0
        for y in [0,1]:
            for x in [1,2]:
                if work[y][x] == '1':
                    temp[0][1] = temp[0][1] + 1

    if work[0][SIZE] == '1':
        temp[0][SIZE] = -1
        for y in [0,1]:
            for x in [SIZE-1,SIZE]:
                if work[y][x] == '1':
                    temp[0][SIZE] = temp[0][SIZE] + 1
    if work[0][SIZE] == '0':
        temp[0][SIZE] = 0
        for y in [0,1]:
            for x in [SIZE-1,SIZE]:
                if work[y][x] == '1':
                    temp[0][SIZE] = temp[0][SIZE] + 1

    if work[SIZE-1][1] =='1':
        temp[SIZE-1][1] = -1
        for y in [SIZE-2,SIZE-1]:
            for x in [1,2]:
                if work[y][x] =='1':
                    temp[SIZE-1][1] = temp[SIZE-1][1] + 1
    if work[SIZE-1][1] == '0':
        temp[SIZE-1][1] = 0
        for y in [SIZE - 2, SIZE - 1]:
            for x in [1, 2]:
                if work[y][x] == '1':
                    temp[SIZE - 1][1] = temp[SIZE - 1][1] + 1

    if work[SIZE-1][SIZE] =='1':
        temp[SIZE-1][SIZE] = -1
        for y in [SIZE-2,SIZE-1]:
            for x in [SIZE-1,SIZE]:
                if work[y][x] =='1':
                    temp[SIZE-1][SIZE] = temp[SIZE-1][SIZE] +1
    if work[SIZE-1][SIZE] =='0':
        temp[SIZE-1][SIZE] = 0
        for y in [SIZE-2,SIZE-1]:
            for x in [SIZE-1,SIZE]:
                if work[y][x] =='1':
                    temp[SIZE-1][SIZE] = temp[SIZE-1][SIZE] +1

    #for cells at 4 sides
    for x in range(2,SIZE):
        if work[0][x] == '1':
            temp[0][x] = -1
            for x_temp in [x-1,x,x+1]:
                for y_temp in [0,1]:
                    if work[y_temp][x_temp] == '1':
                        temp[0][x] = temp[0][x] +1
        if work[0][x] =='0':
            temp[0][x] = 0
            for x_temp in [x - 1, x, x + 1]:
                for y_temp in [0, 1]:
                    if work[y_temp][x_temp] == '1':
                        temp[0][x] = temp[0][x] + 1

    for x in range(2,SIZE):
        if work[SIZE-1][x] == '1':
            temp[SIZE-1][x] = -1
            for x_temp in [x-1,x,x+1]:
                for y_temp in [SIZE-2,SIZE-1]:
                    if work[y_temp][x_temp] == '1':
                        temp[SIZE-1][x] = temp[SIZE-1][x] +1
        if work[SIZE-1][x] =='0':
            temp[SIZE-1][x] = 0
            for x_temp in [x-1,x,x+1]:
                for y_temp in [SIZE-2,SIZE-1]:
                    if work[y_temp][x_temp] == '1':
                        temp[SIZE-1][x] = temp[SIZE-1][x] +1

    for y in range(1,SIZE-1):
        if work[y][1] == '1':
            temp[y][1] = -1
            for y_temp in [y-1,y,y+1]:
                for x_temp in [1,2]:
                    if work[y_temp][x_temp] =='1':
                        temp[y][1] = temp[y][1] + 1
        if work[y][1] == '0':
            temp[y][1] = 0
            for y_temp in [y-1,y,y+1]:
                for x_temp in [1,2]:
                    if work[y_temp][x_temp] =='1':
                        temp[y][1] = temp[y][1] + 1

    for y in range(1,SIZE-1):
        if work[y][SIZE] =='1':
            temp[y][SIZE] = -1
            for y_temp in [y-1,y,y+1]:
                for x_temp in [SIZE,SIZE-1]:
                    if work[y_temp][x_temp] =='1':
                        temp[y][SIZE] = temp[y][SIZE] + 1
        if work[y][SIZE] =='0':
            temp[y][SIZE] = 0
            for y_temp in [y-1,y,y+1]:
                for x_temp in [SIZE,SIZE-1]:
                    if work[y_temp][x_temp] =='1':
                        temp[y][SIZE] = temp[y][SIZE] + 1

    #for cells at center
    for x in range(2,SIZE):
        for y in range(1,SIZE-1):
            if work[y][x] == '1':
                temp[y][x] = -1
                for x_temp in [x-1,x,x+1]:
                    for y_temp in [y-1,y,y+1]:
                        if work[y_temp][x_temp] =='1':
                            temp[y][x] = temp[y][x] + 1
            if work[y][x] == '0':
                temp[y][x] = 0
                for x_temp in [x-1,x,x+1]:
                    for y_temp in [y-1,y,y+1]:
                        if work[y_temp][x_temp] =='1':
                            temp[y][x] = temp[y][x] + 1

    for x in range(1,SIZE+1):
        for y in range(0,SIZE):
            if work[y][x] == '1':
                if temp[y][x] < 2:
                    work[y][x] = '0'
                if temp[y][x]>=2 and temp[y][x]<=3:
                    work[y][x] = '1'
                else:
                    work[y][x] = '0'

            if work[y][x] =='0':
                if temp[y][x] ==3:
                    work[y][x] = '1'

    return work

# Initialize work and temp:
work = ['0']*(SIZE)
temp = ['0']*(SIZE)
initial = ['0']*(SIZE+2)

#using deepcopy not to aliase list
for y in range(SIZE):
    work[y] = copy.deepcopy(initial)
    work[y][0] = '|'
    work[y][SIZE+1] = '|'

for y in range(SIZE):
    temp[y] = copy.deepcopy(initial)

#initial setting(generation 0)
work[0][2] = '1'
work[1][2] = '1'
work[2][2] = '1'
work[10][11] = '1'
work[10][12] = '1'
work[10][13] = '1'
work[11][11] = '1'
work[12][11] = '1'
work[12][12] = '1'
work[12][13] = '1'

# Compute:
n = 1
while n<=TIMES:
    printWorld(work)
    liveChange()
    time.sleep(1)
    n = n+1