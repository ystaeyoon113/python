def copyFiles(f1, f2, f3):
    """
    Copies files f1 and f2 onto file f3.
    If f1, f2 or f3 cannot be opened, -1 is returned.
    Otherwise, the copy operation is performed and 0 is returned.
    """

############################main##############################
    try:
        # open file 1,2,3
        file1 = open(f1, 'r')
        file2 = open(f2, 'r')
        file3 = open(f3, 'w')

        # read file1 line
        copy_1 = file1.readline()

        # iterate while copy is over
        while copy_1 != '':
            # copy onto file3 and re copy file1
            file3.write(copy_1)
            copy_1 = file1.readline()

        # close file1
        file1.close()

        # read file2 line
        copy_2 = file2.readline()

        # iterate while copy is over
        while copy_2 != '':
            # copy onto file3 and re copy file2
            file3.write(copy_2)
            copy_2 = file2.readline()

        # close fil2 and file3
        file2.close()
        file3.close()

        #return 0
        return 0

    #if files are unable to open, return -1
    except OSError:
        return -1