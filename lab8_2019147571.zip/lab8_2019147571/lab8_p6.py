import turtle

def drawSquare(myturtle, x, y, a):
    """
    :param myturtle: turtle drawing object to be used
    :param x,y: x and y coordinates of the lower left corner of the square
    :param a:length of each side of the square.
    :return:a Square
    """

    myturtle.penup()
    myturtle.setposition(x,y)               #set initial position without drawing
    myturtle.pendown()

    for num in range(0,4):                  #for loop to process repeated drawing
        myturtle.forward(a)                #go forward lenght a
        myturtle.left(90)                  #turn left 90 degrees to make square
