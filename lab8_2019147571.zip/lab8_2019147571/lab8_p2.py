def removeValuesInPlace(L,threshold):
    """
    remove members in list L if member is above threshold
    """
    M=[]                                    #Make New list to not mutate L
    for num in range(0,len(L)):             #Iterating use for loop
        if L[num]<=threshold:               #If member of L is not above threshold
            M.append(L[num])                #append member in M

    return M

