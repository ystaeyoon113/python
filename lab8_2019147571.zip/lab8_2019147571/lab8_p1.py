def resetValuesInPlace(L, threshold):
    """
    reset value in L to zero if member is above threshold
    """
    for num in range(0,len(L)):                       #for every member of list L
        if L[num] >threshold:                         #decide if list L is over threshold
            L[num]=0                                  #L[num] becomes 0 if L[num]>threshold

    return L
