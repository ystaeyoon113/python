import turtle

turtle.setup(800,600)                       #window size:800*600

window = turtle.Screen()

mine = turtle.getturtle()
mine = turtle.hideturtle()                  #To make only X in window
mine = turtle.setposition(-400,-300)        #Make turtle move by absolute positioning
mine = turtle.setposition(400,300)         #Draw line by absolute positioning

mine = turtle.penup()                       #Pen up to move without drawing
mine = turtle.setposition(-400,300)
mine = turtle.pendown()                     #Pen down to move with drawing

mine = turtle.setposition(400,-300)

window.exitonclick()                        #Terminate when user clicks
