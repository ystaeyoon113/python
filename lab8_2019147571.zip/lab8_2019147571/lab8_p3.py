def resetValues(L, threshold):
    """
    change member of L to 0 of it is above threshold
    """
    Result=[]                           #Make new list to not mutate L
    for num in range(0,len(L)):         #Iterating using for loop
        if L[num]>threshold:
            Result.append(0)            #L[num] is replaced by 0

        else:                           #If L[num]is not above threshold
            Result.append(L[num])

    return Result