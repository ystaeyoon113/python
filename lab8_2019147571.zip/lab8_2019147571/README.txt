Lab 8 answers by Kim Taeyoon, student ID 2019147571

Q1:
(a)
11 20
if you return n =11 in foo1(n), it is just n in the foo1(n) frame.
In global frame, n is still 10.

(b)
2
in global frame, x=0.
but in foo(): frame, x=1. so when you use function foo(), in the foo() frame x is 1.
and in bar(): frame, x is loaded from foo(): frame. so x=1, y=2

(c)
1
in global frame, x=0.
and in foo():, #x=1 doesn't work. so x should be loaded from global frame. so x=0
in bar():, x should be loaded from global frame. so x=0, y=1