
def drawFlower(myturtle, r):
    """
    Draws a flower composed of 24 circles
    on the screen. The radius of the
    circle is "r".
    The drawing color is "red".
    The turtle "myturtle" is already
    positioned in the center of the flower.
    """
    #hide turtle
    myturtle.hideturtle()

    #set pencolor
    myturtle.pencolor('red')

    #draw circle with angle change
    for angle in range(0,360,15):
        myturtle.setheading(angle)
        myturtle.circle(r)
