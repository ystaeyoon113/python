import stack
import sys

#user input
RPN = input('Enter an RPN expression: ')

#initialize boolian flag
terminate = False

#iterating by boolian flag
while not terminate:
    #get new stack
    operand = stack.getStack()

    #split into item
    item = RPN.split(' ')

    #terminate if '=' is not at right-most
    if item[len(item)-1] != '=':
        print('Evaluation error')
        sys.exit()

    #iterating for loop
    for i in range(0,len(item)-1):

        #if item[i] is an integer
        if item[i] not in ('+','-','*','/','='):
            num = float(item[i])
            stack.push(operand, num)

        else:
            #pop two operands
            n1 = stack.pop(operand)
            n2 = stack.pop(operand)

            #For malformed expression
            if n1==None or n2==None:
                print('Evaluation error')
                sys.exit()

            #execute operation and save it to stack
            if item[i] == '+':
                n3 = n2 + n1
                stack.push(operand, n3)

            if item[i] == '*':
                n3 = n2 * n1
                stack.push(operand, n3)

            if item[i] == '-':
                n3 = n2 - n1
                stack.push(operand, n3)

            if item[i] == '/':
                n3 = n2 / n1
                stack.push(operand, n3)

            #For malformed expression
            if item[i] == '=':
                print('Evaluation error')
                sys.exit()

    #For malformed expression
    if len(operand)!=1:
        print('Evaluation error')
        sys.exit()

    #returns result value
    result = stack.pop(operand)

    #decide result type and print
    if float.is_integer(result)==True:
        result = int(result)
        print('Value of expression:',result)

    else:
        print('Value of expression:',format(result,'.2f'))

    # user input
    RPN = input('Enter an RPN expression: ')
    if RPN == 'q':
        terminate = True
