#welcome
print('This program can determine if given string is a palindrome\n')
print('(Enter return to exit)')

#boolian flag for terminate
terminate = False

#user input
user = input('Enter string to check: ')
if user =='':
    terminate = True

while not terminate:
    #check input length
    num = len(user)//2

    #initial boolian flag
    palindrome = True

    #iterate by for loop
    for i in range(0,num):
        #compare from front and back
        if user[i] != user[len(user)-1-i]:
            palindrome = False

    #print
    if palindrome:
        print(user,'is a palindrome')

    else:
        print(user,'is NOT a palindrome')

    #if terminate or not
    user = input('Enter string to check: ')
    if user == 'return':
        terminate = True
