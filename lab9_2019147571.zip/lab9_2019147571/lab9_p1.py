import stack

#user input
user = input('Enter parentheses and/or braces: ')

#get new stack
left = stack.getStack()

#if user input is odd
if len(user)%2 ==1:
    print('Not properly nested.')

#If user input is even
else:

    #Initialize Boolian Flag
    nested = True

    #iterating by Boolian flag
    if nested:
        for k in range(0,len(user)):

            #push item in stack
            if user[k]=='(' or user[k]=='{':
                stack.push(left,user[k])

            #if input is ')'
            if user[k]==')':
                if stack.top(left)=='(':
                    stack.pop(left)
                else:
                    nested = False                 #change nested to False and terminate

            #if input is '}'
            if user[k]=='}':
                if stack.top(left)=='{':
                    stack.pop(left)
                else:
                    nested=False                  #change nested to False and terminate

    if nested:                                    #if nested stil remains to True
        print('Nested properly.')
    else:                                         #if nested had changed to False
        print('Not properly nested.')

