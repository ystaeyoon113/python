#User Input
Name_list = []           #Make Name List
Name = str(input('Enter a name (q to quit): '))

#Initial Setting
Number = -1
i=0
Appearance = 0

while Name!='q':
    Name_list.append(Name)                              #Appending Name in Name_list
    Number = Number + 1                                 #To count how many strings are in Name_list
    Name = str(input('Enter a name (q to quit): '))     #Loop


if Name=='q':                                                            #Terminating Process
    while i<=Number:
        Value = str(Name_list[i])                                        #Transforming into string to count 'a' and 'A'
        Appearance = Appearance + Value.count('a') + Value.count('A')    #Summing Appearance
        i = i+1                                                          #To Call Next string and stop loop
    print("Appearance of letter 'a':",Appearance)                        #Terminating Process
