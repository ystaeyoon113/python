#First User Input
Input = float(input('Enter a number: '))

#For No positive input
if Input<=0:
    print('No positive number was entered')

#For positive input
if Input>0:
    Largest = Input   #Define "Largest"
    Input_New = float(input('Enter a number: ')) #For New Input

    while Input_New>0:
        if Largest-Input_New>=0:    #Figure out which is Largest
            Largest = Largest
        else:
            Largest = Input_New
        Input_New = float(input('Enter a number: '))    #For New Input


    if Input_New<=0:   #Terminating Processs
        print('The largest number entered was',format(Largest,'.2f'))
