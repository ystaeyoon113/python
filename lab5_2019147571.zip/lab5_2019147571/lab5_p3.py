#User Input
Input = int(input('Enter an integer: '))

#Make List
List =[]

#When Input!=0, append Input
while Input!=0:
    if Input>100:  #append str(over)
        List.append('over')
    if Input<=100:    #append int(Input)
        List.append(Input)
    Input = int(input('Enter an integer: '))

#Terminating Process
if Input==0:
    print(List)