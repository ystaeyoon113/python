#User Input
Sentence = str(input('Enter a sentence: '))

#Counting Vowel Strings
a = Sentence.count('a')+ Sentence.count('A')
e = Sentence.count('e')+ Sentence.count('E')
i = Sentence.count('i')+ Sentence.count('I')
o = Sentence.count('o')+ Sentence.count('O')
u = Sentence.count('u')+ Sentence.count('U')
#Total Vowels
N = a+e+i+o+u
#Terminating Process, Distinguish singular and plurals
if N==1:
    print('Your sentence contains 1 vowel.')
else:
    print('Your sentence contains',N,'vowels.')
