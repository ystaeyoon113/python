#User Input
Height = int(input('Enter an integer: '))

#Setting to Make Blank and Line
Blank = 0
Width = 2*Height-1

#Loop until width is 1
while Width!=-1:
    print(' '*Blank +'*'*Width)     #cannot use format to center string
    Width = Width-2                 #so I used Blank to center string
    Blank = Blank+1
