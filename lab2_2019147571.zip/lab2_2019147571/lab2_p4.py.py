#user input

x = int(input('Number 1: '))
y = int(input('Number 2: '))

#result calculation

N = format(x/y, '.2f')
print('Result:', ' ',N)