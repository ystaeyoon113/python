#value define

a = int(input('Enter leftmost digit: '))
b = int(input('Enter the left digit: '))
c = int(input('Enter the left digit: '))
d = int(input('Enter the left digit: '))

#digit transforming
N =a*2**3 + b*2**2 + c*2**1 + d*2**0

#print
print('The value is ',N)
