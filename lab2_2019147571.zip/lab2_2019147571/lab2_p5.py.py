print('This program will convert degrees Celsius to degrees Fahrenheit')
c = float(input('Enter degrees Celsius: '))

f= format(c*9/5 + 32,'.1f')



print(c,' degrees Celsius equals ',f,' degrees Fahrenheit')
