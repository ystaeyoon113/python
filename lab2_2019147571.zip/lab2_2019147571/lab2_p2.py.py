# string define

base = int(input('What base? '))
power = int(input('What power of' + ' '+ str(base) +'? '))

# result
N = base**power

# print
print(base , 'to the power of', power, 'is', N)







