#define function
def myAverage(x,y,z):
    """
    returns average of x,y,z
    """
    return (x + y + z)/3

#loading from text
text = open('data.txt','r')

#make list
origin = []
result = []

#appending members to origin
num = text.readline()
while num !='':
    origin.append(num)
    num = text.readline()

#close text
text.close()

#make new list
list = [origin[0]] + origin + [origin[len(origin)-1]]

#iterate by for loop
for i in range(1,len(list)-1):
    #get average of three members
    result.append(myAverage(int(list[i-1]),int(list[i]),int(list[i+1])))

#print and terminate
print(result)