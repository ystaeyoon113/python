def countLetters(line):
    #initialize count number
    k = 0

    #iterate each string
    for i in range(0,len(line)):

        #using ASCII number
        if 97<=ord(line[i])<=122 or 65<=ord(line[i])<=90:
            k = k+1

    #adding new file
    newfile = open('answer.txt', 'w')
    newfile.write(str(k)+'\n')
    newfile.close()