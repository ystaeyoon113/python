def countAllLetters(line):
    """
    Counts letters in 'line' and returns result list. If the line
    does not contain any letter, returns an empty list.
    """
    #make new list
    word_list = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n'
        ,'o','p','q','r','s','t','u','v','w','x','y','z']
    num_list = [0]*26
    print_list = []

    #make line lower case
    new_line = line.lower()

    #using for loop to compare each string object
    for i in range(0,len(new_line)):
        #if string object is alphabetic, count
        if new_line[i] in word_list:
            #use index to find alphabet order
            x = word_list.index(new_line[i])
            num_list[x] = num_list[x] + 1

    #appending to new list to print
    for n in range(0,26):
        if num_list[n] != 0:
            print_list.append((word_list[n], num_list[n]))

    #return and terminate
    return(print_list)

