def copyFiles(f1,f2,f3):
    """
    Copies f1 and f2 onto f3.

    The function assumes that files f1 and f2 can be opened, and that
    no error occurs in writing file f3.
    Therefore, the function will always return 0.
    """

    #open file 1,2,3
    file1 = open(f1, 'r')
    file2 = open(f2, 'r')
    file3 = open(f3, 'w')

    #read file1 line
    copy_1 = file1.readline()

    #iterate while copy is over
    while copy_1 !='':
        #copy onto file3 and re copy file1
        file3.write(copy_1)
        copy_1 = file1.readline()

    #close file1
    file1.close()

    #read file2 line
    copy_2 = file2.readline()

    #iterate while copy is over
    while copy_2 !='':
        #copy onto file3 and re copy file2
        file3.write(copy_2)
        copy_2 = file2.readline()

    #close fil2 and file3
    file2.close()
    file3.close()


