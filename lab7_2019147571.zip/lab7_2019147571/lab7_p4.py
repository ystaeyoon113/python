def evalPolynomial(x):
    """
    :param x: user input
    :return: y = evaluated by polynomial
    """

    y = 3*x**5 + 2*x**4 - 5*x**3 - x**2 +7*x -6         #define y in function frame
    return y

x = int(input('Enter a value for x: '))                 #define x in global frame
print('Polynomial for x=5:',evalPolynomial(x))
