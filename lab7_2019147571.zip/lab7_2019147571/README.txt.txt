Lab 7 answers by Kim Taeyoon, student ID  2019147571

Q1:
(b),(c),(d),(e)


Q2:
(a) proper
(b) improper. Because 10.0 is not int, it is float
(c) improper. Because n1 is larger than n2
(d) proper
(e) improper. Because n1 is larger than n2 in gcd(c,b)


Q3:
True. l1 = [1,2,['foo']] l2 = [['foo'],5]
so l2[0] and l1[2] has same identity.