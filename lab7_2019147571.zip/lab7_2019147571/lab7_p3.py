def modCount(n,m):
    """
    :param m:dividing number
    :param n:to which extent
    :return:how many numbers between [1,n] which is evenly divisible
    """
    return n//m                     #n//m heldps to find return
                                    #because it throws away the remainder
                                    #so it can divide the largest evenly disivible number