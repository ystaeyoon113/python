def zeroCheck (x,y,z):
    """
    :param x: number 1
    :param y: number 2
    :param z: number 3
    :return: true or false
    """
    if x*y*z==0:                                        #If x=0 or y=0 or z=0, x*y*z = 0
        return 'true'
    else:                                               #If x!=0 and y!=0 and z!=0
        return 'false'