#defining tuple to use while loop
text_list = ('GS1 prefix', 'Group identifier', 'Publisher code', 'Item number','Check digit')

#User Input
ISBN = input('Enter an ISBN: ')

#split to make to list
num_list = ISBN.split('-')

#Initializing i
i=0

#while loop to print 5 texts
while i<=4:
    print(format(num_list[i],'.<20')+text_list[i])
    i=i+1

