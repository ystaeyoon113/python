def ordered3 (x,y,z):
    """
    :param x: number1
    :param y: number2
    :param z: number3
    :return: true or false
    """

    if x<=y and y<=z:                   #x<=y<=z
        return 'true'
    else:                               #not x<=y<=z
        return 'false'

