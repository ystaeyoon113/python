Lab 6 answers by Kim Taeyoon, student ID 2019147571

Q1:
(a) print(str1[3])
(b) str1.index('o')

Q2:
(a) len(lst)
(b)
i=0
for N in lst:
    i = i+len(N)
(c)
j=0
for N in lst:
    for e in N:
        j = j+e

(d)
lst[3][2] = 12

Q3:
(a)
list1[0] = 10 ,list2[0] = 50
(b)
list1[0] = 1 , list2[0] = 1
(c)
list1[0] = 1 , list2[0] = 15
(d)
list1[0] = 0, list2[0] = 5
