#User Input
Input = str(input('Enter a fraction: '))

#Initial Setting
List = []
k = 0

#Split string into List
while k<len(Input):
    List.append(Input[k])
    k=k+1

#Find where is '/'
Index = List.index('/')

#Divide into two part(numerator/denominator)
Up = List[:Index]
Down = List[Index+1:]

#(numerator) save number only
while ' 'in Up:
    Up.remove(' ')
N = len(Up)
i=0
numerator = 0

#(denominator) save number only
while ' 'in Down:
    Down.remove(' ')
M = len(Down)
j=0
denominator = 0

#translating numerator string into int by ASCII number
while i<N:
    numerator = numerator + 10**(N-i)*(ord(Up[i])-48)
    i = i+1

#translating denominator string into int by ASCII number
while j<M:
    denominator = denominator + 10**(M-j)*(ord(Down[j])-48)
    j = j+1

#Use Euclid's algorithm to find GCD
if numerator > denominator:
    num_1 = numerator
    num_2 = denominator

    R = num_1%num_2
    if R == 0:
        print('In lowest terms:',format(num_1/num_2,'.0f'))
    while R!=0:
        num_1 = num_2
        num_2 = R
        R = num_1%num_2

        if R==0:
            GCD = num_2
        print('In lowest terms:',end=' ')
        print(format(numerator / GCD,'.0f'),end='')
        print('/',end='')
        print(format(denominator / GCD,'.0f'))

#Use Euclid's algorithm to find GCD
if numerator < denominator:
    num_1 = denominator
    num_2 = numerator

    R = num_1%num_2
    while R!=0:
        num_1 = num_2
        num_2 = R
        R = num_1%num_2
    if R==0:
            GCD = num_2

    print('In lowest terms:', end=' ')
    print(format(numerator / GCD, '.0f'), end='')
    print('/', end='')
    print(format(denominator / GCD, '.0f'))