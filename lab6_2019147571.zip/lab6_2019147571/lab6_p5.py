#Initial Setting // User Input
List = []
Fruit = []
i = 0
Fruit_Input = str(input('Enter a fruit type (q to quit): '))

#If User inserted 'q' first
if Fruit_Input =='q':
    print('No data received, exiting.')


if Fruit_Input !='q':
    while Fruit_Input !='q':

        if Fruit_Input not in Fruit:
            Fruit.append(Fruit_Input)                                       #If first time, save Fruit
            Value_Input = int(input('Enter the weight in kg: '))
            List.append([Fruit_Input,Value_Input])                          #List Fruit and Value Together
            Fruit_Input = str(input('Enter a fruit type(q to quit): '))

        if Fruit_Input in Fruit:
            Index = Fruit.index(Fruit_Input)
            Value_Input = int(input('Enter the weight in kg: '))
            List[Index][1] = List[Index][1] + Value_Input                  #If not first time, summing value
            Fruit_Input = str(input('Enter a fruit type(q to quit): '))

    if Fruit_Input =='q':
        from operator import itemgetter                               #Use function itemgetter
        List.sort(key=itemgetter(0))                                 #to sort only by Fruit name
        while i<=len(List)-1:
            print(List[i][0],end='')
            print(', ',end='')
            print(List[i][1],end='')
            print('kg.')
            i = i+1
