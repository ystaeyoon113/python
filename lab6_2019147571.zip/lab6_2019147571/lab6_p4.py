#Initial setting // User Input
Word = []
Input = str(input('Enter a word (q to quit): '))

#Translate first word into ASCII number
while Input !='q':
    N = ord(Input[0])
    if N<=90:              #If word is upper case
        M = N+32

    if N>90:               #If word is lower case
        M = N-32

#Find if first word repeat
    S = Input.count(chr(M)) + Input.count(chr(N))
    if S>=2:
        Word.append(Input)

    Input = str(input('Enter a word (q to quit): '))

#Print after using sort()
if Input =='q':
    Word.sort()
    print(Word)

