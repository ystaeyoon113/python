#Initial Setting // User Input
n = 1
Sum = 0
Input = int(input('Enter the limit L: '))

#If Input is 0 or not -> to judge keep loop or terminate
while Input != 0:
    while n<=Input:                #Summing Part
        Sum = Sum + 1/n
        n = n+1

    print('Sum of the initial',Input,'term(s):',format(Sum,'.6f'))

    Input = int(input('Enter the limit L: '))            #Initialize n and Sum and Loop
    n = 1
    Sum = 0