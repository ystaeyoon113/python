#Input User Name
Full_Name = str(input('Enter a first and last name: '))

#Use split function to make List
List = Full_Name.split(' ')

#remove blank to save name
while ''in List:
    List.remove('')

#print Initial
print(List[1],end='')
print(', ',end='')
print(List[0][0],end='')
print('.')
