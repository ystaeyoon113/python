Lab 4 answers by Kim Taeyoon, student ID 2019147571

Q1: (a) (var*8) - var2 + (32/var3)
    (b) var1- {(6**4) * (var2**3)}

Q2: (a) var1 *(1) var2 *(2) var3 -(3) var4
       Operator associativity is used to resolve ambiguity between operators *(1) and *(2).
       The direction is left to right
    (b) var1 *(1) var2 /(2) var3
       Operator associativity is used to resolve ambiguity between operators *(1) and /(2).
       The direction is left to right
    (c) var1 **(2) var2 **(1) var3
       Operator associativity is used to resolve ambiguity between operators **(1) and **(2).
       The direction is right to left

Q3: a,b

Q4: (a) 24 not in nums
    (b) 'Ellen' in names
    (c) 'Morris' in last_name or 'Morrison' in last_name

Q5: print('John Doe\n123 Main Street\nAnytown, Maryland 21009')

Q6: print("It's raining today.")

Q7: (a)2.0
    (b)2
    (c)2.0