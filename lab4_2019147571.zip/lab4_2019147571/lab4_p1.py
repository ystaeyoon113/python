#User input
N = int(input('Enter the taxable income in USD: '))

#if-elif-else
if N<=750:
    T = N/100
elif N<=2250:
    T = 7.50+(N-750)*2/100
elif N<=3750:
    T = 37.50+(N-2250)*3/100
elif N<=5250:
    T = 82.50+(N-3750)*4/100
elif N<=7000:
    T = 142.50+(N-5250)*5/100
else:
    T = 230.00+(N-7000)*6/100
#format print
print('Tax due:',format(T,'.2f'),'USD')
