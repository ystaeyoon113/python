#user input
N = int(input('Enter a number: '))

#initial define
M = N//10
digit = 1

#use (if) to judge print 'digit' or 'digits'
if M==0:
    print('The number',N,'contains 1 digit')

#loop to find digit
while M >=1:
    M = M//10
    digit = digit + 1
    if M==0:
        print('The number',N,'contains',digit,'digits')



