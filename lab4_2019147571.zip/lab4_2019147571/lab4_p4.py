#define
start = 1

#loop until 100
while start<=100:
    #while statement to judge new line
    while start%10!=0:
         print(format(start,'>3'),end='')
         start = start + 1

    while start%10==0:
         print(format(start,'>3'))
         start = start + 1


