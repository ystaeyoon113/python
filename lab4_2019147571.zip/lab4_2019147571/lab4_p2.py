#user input
N = int(input('Your number: '))

#define S
S = 0
#loop
while N!=0: #necessary!!
    while N>100:
        S = S
        N = int(input('Your number: '))

    while N > 0 and N <= 100:
        S = S + N
        N = int(input('Your number: '))
#If statement (end phrase)
if N==0:
    print('Sum:',S)